#!/usr/bin/env python3
"""Assemble completed unsure_words batches into the deck JSON."""
from __future__ import annotations
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
SOURCE = BASE / "unsure-words.txt"
BATCH_DIR = Path(__file__).resolve().parent
OUTPUT = BASE.parents[1] / "Lexico" / "Resources" / "Cards" / "unsure_words_en.json"
CATEGORY_NAMES = {
    "card.category.position_and_direction": {"en": "Position and Direction", "ru": "Положение и направление"},
    "card.category.contrast_and_concession": {"en": "Contrast and Concession", "ru": "Противопоставление и уступка"},
    "card.category.emotions_and_reactions": {"en": "Emotions and Reactions", "ru": "Эмоции и реакции"},
    "card.category.position_and_group": {"en": "Position and Groups", "ru": "Положение и группы"},
    "card.category.planning_and_order": {"en": "Planning and Order", "ru": "Планирование и порядок"},
    "card.category.knowledge_and_awareness": {"en": "Knowledge and Awareness", "ru": "Знание и осведомлённость"},
    "card.category.causes_and_results": {"en": "Causes and Results", "ru": "Причины и следствия"},
    "card.category.qualities_and_traits": {"en": "Qualities and Traits", "ru": "Качества и свойства"},
    "card.category.degree_and_extension": {"en": "Degree and Extension", "ru": "Степень и продолжение"},
    "card.category.looking_and_observing": {"en": "Looking and Observing", "ru": "Взгляд и наблюдение"},
    "card.category.actions_and_control": {"en": "Actions and Control", "ru": "Действия и управление"},
    "card.category.importance_and_relevance": {"en": "Importance and Relevance", "ru": "Важность и значимость"},
    "card.category.certainty_and_confidence": {"en": "Certainty and Confidence", "ru": "Уверенность и достоверность"},
    "card.category.food_and_objects": {"en": "Food and Objects", "ru": "Еда и предметы"},
    "card.category.clothing_and_personal_items": {"en": "Clothing and Personal Items", "ru": "Одежда и личные вещи"},
    "card.category.shapes_and_boundaries": {"en": "Shapes and Boundaries", "ru": "Формы и границы"},
    "card.category.choices_and_alternatives": {"en": "Choices and Alternatives", "ru": "Выбор и альтернативы"},
    "card.category.appearance_and_quality": {"en": "Appearance and Quality", "ru": "Внешний вид и качество"},
    "card.category.specificity_and_detail": {"en": "Specificity and Detail", "ru": "Конкретика и подробности"},
    "card.category.possibility_and_uncertainty": {"en": "Possibility and Uncertainty", "ru": "Возможность и неопределённость"},
    "card.category.removal_and_freedom": {"en": "Removal and Freedom", "ru": "Избавление и освобождение"},
    "card.category.waste_and_nonsense": {"en": "Waste and Nonsense", "ru": "Отходы и чепуха"},
    "card.category.resolution_and_change": {"en": "Resolution and Change", "ru": "Решение и изменения"},
    "card.category.speech_and_sound": {"en": "Speech and Sound", "ru": "Речь и звуки"},
    "card.category.closure_and_access": {"en": "Closure and Access", "ru": "Закрытие и доступ"},
    "card.category.degree_and_importance": {"en": "Degree and Importance", "ru": "Степень и важность"},
    "card.category.mistakes_and_accidents": {"en": "Mistakes and Accidents", "ru": "Ошибки и происшествия"},
    "card.category.change_and_surprise": {"en": "Change and Surprise", "ru": "Изменения и неожиданности"},
    "card.category.clothing_and_connections": {"en": "Clothing and Connections", "ru": "Одежда и связи"},
    "card.category.time_and_duration": {"en": "Time and Duration", "ru": "Время и длительность"},
    "card.category.wear_and_fatigue": {"en": "Wear and Fatigue", "ru": "Износ и усталость"},
    "card.category.direction_and_relation": {"en": "Direction and Relation", "ru": "Направление и отношение"},
    "card.category.transport_and_parts": {"en": "Transport and Parts", "ru": "Транспорт и детали"},
    "card.category.rules_and_sources": {"en": "Rules and Sources", "ru": "Правила и источники"},
    "card.category.adjustment_and_learning": {"en": "Adjustment and Learning", "ru": "Адаптация и обучение"},
    "card.category.benefits_and_advantages": {"en": "Benefits and Advantages", "ru": "Польза и преимущества"},
    "card.category.communication_and_advice": {"en": "Communication and Advice", "ru": "Общение и советы"},
    "card.category.events_and_relationships": {"en": "Events and Relationships", "ru": "События и отношения"},
    "card.category.effects_and_influence": {"en": "Effects and Influence", "ru": "Воздействие и влияние"},
    "card.category.help_and_support": {"en": "Help and Support", "ru": "Помощь и поддержка"},
    "card.category.summary_and_degree": {"en": "Summary and Degree", "ru": "Итог и степень"},
    "card.category.news_and_announcements": {"en": "News and Announcements", "ru": "Новости и объявления"},
    "card.category.attraction_and_requests": {"en": "Attraction and Requests", "ru": "Привлекательность и просьбы"},
    "card.category.roles_and_selection": {"en": "Roles and Selection", "ru": "Роли и выбор"},
    "card.category.position_and_emphasis": {"en": "Position and Emphasis", "ru": "Положение и акцент"},
    "card.category.groups_and_connections": {"en": "Groups and Connections", "ru": "Группы и связи"},
    "card.category.beliefs_and_assumptions": {"en": "Beliefs and Assumptions", "ru": "Убеждения и предположения"},
    "card.category.confidence_and_reassurance": {"en": "Confidence and Reassurance", "ru": "Уверенность и заверения"},
    "card.category.presence_and_attention": {"en": "Presence and Attention", "ru": "Присутствие и внимание"},
    "card.category.behaviour_and_opinions": {"en": "Behaviour and Opinions", "ru": "Поведение и взгляды"},
    "card.category.covering_and_exposure": {"en": "Covering and Exposure", "ru": "Покрытие и открытие"},
    "card.category.food_and_plants": {"en": "Food and Plants", "ru": "Еда и растения"},
    "card.category.pleading_and_requests": {"en": "Pleading and Requests", "ru": "Уговоры и просьбы"},
    "card.category.ownership_and_place": {"en": "Ownership and Place", "ru": "Принадлежность и место"},
    "card.category.ties_and_constraints": {"en": "Ties and Constraints", "ru": "Связи и ограничения"},
    "card.category.lending_and_borrowing": {"en": "Lending and Borrowing", "ru": "Займы и одалживание"},
    "card.category.transport_and_parts": {"en": "Transport and Parts", "ru": "Транспорт и детали"},
    "card.category.body_and_health": {"en": "Body and Health", "ru": "Тело и здоровье"},
    "card.category.shortness_and_summaries": {"en": "Shortness and Summaries", "ru": "Краткость и сводки"},
    "card.category.width_and_scope": {"en": "Width and Scope", "ru": "Ширина и охват"},
    "card.category.money_and_animals": {"en": "Money and Animals", "ru": "Деньги и животные"},
    "card.category.contact_and_increase": {"en": "Contact and Increase", "ru": "Столкновения и увеличение"},
    "card.category.groups_and_amounts": {"en": "Groups and Amounts", "ru": "Группы и количества"},
    "card.category.containers_and_storage": {"en": "Containers and Storage", "ru": "Ёмкости и хранение"},
    "card.category.limits_and_covering": {"en": "Limits and Covering", "ru": "Ограничения и покрытие"},
    "card.category.ability_and_skills": {"en": "Ability and Skills", "ru": "Способности и навыки"},
    "card.category.performance_and_roles": {"en": "Performance and Roles", "ru": "Выступления и роли"},
    "card.category.pursuit_and_effort": {"en": "Pursuit and Effort", "ru": "Преследование и усилия"},
    "card.category.encouragement_and_joy": {"en": "Encouragement and Joy", "ru": "Поддержка и радость"},
    "card.category.cut_and_food_prep": {"en": "Cutting and Food Preparation", "ru": "Нарезка и приготовление еды"},
    "card.category.conditions_and_context": {"en": "Conditions and Context", "ru": "Обстоятельства и контекст"},
    "card.category.statements_and_beliefs": {"en": "Statements and Beliefs", "ru": "Утверждения и мнения"},
    "card.category.intelligence_and_skill": {"en": "Intelligence and Skill", "ru": "Сообразительность и умение"},
    "card.category.landforms_and_features": {"en": "Landforms and Features", "ru": "Формы рельефа и особенности"},
    "card.category.evidence_and_discovery": {"en": "Evidence and Discovery", "ru": "Улики и открытия"},
    "card.category.commitment_and_duties": {"en": "Commitment and Duties", "ru": "Обязательства и обязанности"},
    "card.category.understanding_and_confusion": {"en": "Understanding and Confusion", "ru": "Понимание и путаница"},
    "card.category.sharing_and_support": {"en": "Sharing and Support", "ru": "Вклад и поддержка"},
    "card.category.persuasion_and_confidence": {"en": "Persuasion and Confidence", "ru": "Убеждение и уверенность"},
    "card.category.homes_and_buildings": {"en": "Homes and Buildings", "ru": "Жильё и здания"},
    "card.category.government_and_groups": {"en": "Government and Groups", "ru": "Управление и группы"},
    "card.category.movement_and_progress": {"en": "Movement and Progress", "ru": "Движение и продвижение"},
    "card.category.health_and_recovery": {"en": "Health and Recovery", "ru": "Здоровье и выздоровление"},
    "card.category.shapes_and_movements": {"en": "Shapes and Movements", "ru": "Формы и движения"},
    "card.category.risk_and_courage": {"en": "Risk and Courage", "ru": "Риск и смелость"},
    "card.category.day_and_time": {"en": "Day and Time", "ru": "День и время"},
    "card.category.food_and_dining": {"en": "Food and Dining", "ru": "Еда и приёмы пищи"},
    "card.category.guidance_and_control": {"en": "Guidance and Control", "ru": "Руководство и управление"},
    "card.category.movement_and_pull": {"en": "Movement and Pull", "ru": "Движение и тяга"},
    "card.category.time_and_obligation": {"en": "Time and Obligation", "ru": "Сроки и обязательства"},
    "card.category.age_and_family": {"en": "Age and Family", "ru": "Возраст и семья"},
    "card.category.motivation_and_support": {"en": "Motivation and Support", "ru": "Мотивация и поддержка"},
    "card.category.involvement_and_work": {"en": "Involvement and Work", "ru": "Участие и работа"},
    "card.category.creation_and_foundation": {"en": "Creation and Foundation", "ru": "Создание и основы"},
    "card.category.property_and_land": {"en": "Property and Land", "ru": "Имущество и земля"},
    "card.category.faintness_and_loss": {"en": "Faintness and Loss", "ru": "Слабость и обморок"},
    "card.category.fantasy_and_folklore": {"en": "Fantasy and Folklore", "ru": "Фантазия и фольклор"},
    "card.category.belief_and_trust": {"en": "Belief and Trust", "ru": "Вера и доверие"},
    "card.category.interest_and_attention": {"en": "Interest and Attention", "ru": "Интерес и внимание"},
    "card.category.animals_and_nature": {"en": "Animals and Nature", "ru": "Животные и природа"},
    "card.category.people_and_traditions": {"en": "People and Traditions", "ru": "Люди и традиции"},
    "card.category.money_and_planning": {"en": "Money and Planning", "ru": "Деньги и планирование"},
    "card.category.grabbing_and_taking": {"en": "Grabbing and Taking", "ru": "Хватание и взятие"},
    "card.category.elegance_and_kindness": {"en": "Elegance and Kindness", "ru": "Изящество и доброта"},
    "card.category.giving_and_awards": {"en": "Giving and Awards", "ru": "Предоставление и награды"},
    "card.category.shopping_and_food": {"en": "Shopping and Food", "ru": "Покупки и еда"},
    "card.category.piles_and_amounts": {"en": "Piles and Amounts", "ru": "Кучи и количества"},
    "card.category.pauses_and_uncertainty": {"en": "Pauses and Uncertainty", "ru": "Паузы и нерешительность"},
    "card.category.purpose_and_plans": {"en": "Purpose and Plans", "ru": "Цель и намерения"},
    "card.category.food_and_congestion": {"en": "Food and Congestion", "ru": "Еда и заторы"},
    "card.category.interest_and_eagerness": {"en": "Interest and Eagerness", "ru": "Интерес и стремление"},
    "card.category.absence_and_shortage": {"en": "Absence and Shortage", "ru": "Отсутствие и нехватка"},
    "card.category.farm_animals_and_food": {"en": "Farm Animals and Food", "ru": "Домашние животные и еда"},
    "card.category.roads_and_routes": {"en": "Roads and Routes", "ru": "Дороги и маршруты"},
    "card.category.duration_and_endurance": {"en": "Duration and Endurance", "ru": "Длительность и выносливость"},
    "card.category.gardens_and_outdoors": {"en": "Gardens and Outdoors", "ru": "Сады и природа"},
    "card.category.posture_and_amount": {"en": "Posture and Amount", "ru": "Положение и наклон"},
    "card.category.jumps_and_progress": {"en": "Jumps and Progress", "ru": "Прыжки и продвижение"},
    "card.category.loans_and_giving": {"en": "Loans and Giving", "ru": "Займы и предоставление"},
    "card.category.solitude_and_isolation": {"en": "Solitude and Isolation", "ru": "Одиночество и уединение"},
    "card.category.ways_and_behaviour": {"en": "Ways and Behaviour", "ru": "Способы и поведение"},
    "card.category.wonder_and_surprise": {"en": "Wonder and Surprise", "ru": "Удивление и восхищение"},
    "card.category.happiness_and_celebration": {"en": "Happiness and Celebration", "ru": "Радость и праздник"},
    "card.category.measurement_and_distance": {"en": "Measurement and Distance", "ru": "Измерения и расстояние"},
    "card.category.industry_and_milling": {"en": "Industry and Milling", "ru": "Промышленность и помол"},
    "card.category.choices_and_negation": {"en": "Choices and Negation", "ru": "Выбор и отрицание"},
    "card.category.trees_and_materials": {"en": "Trees and Materials", "ru": "Деревья и материалы"},
    "card.category.disagreement_and_resistance": {"en": "Disagreement and Resistance", "ru": "Несогласие и сопротивление"},
    "card.category.common_and_regular": {"en": "Common and Regular", "ru": "Обычное и регулярное"},
    "card.category.debt_and_responsibility": {"en": "Debt and Responsibility", "ru": "Долг и ответственность"},
    "card.category.touching_and_greeting": {"en": "Touching and Greeting", "ru": "Прикосновение и приветствие"},
    "card.category.retirement_and_income": {"en": "Retirement and Income", "ru": "Пенсия и доход"},
    "card.category.stacks_and_piles": {"en": "Stacks and Piles", "ru": "Стопки и груды"},
    "card.category.sport_and_sales": {"en": "Sport and Sales", "ru": "Спорт и продажи"},
    "card.category.ownership_and_control": {"en": "Ownership and Control", "ru": "Владение и контроль"},
    "card.category.liquids_and_flow": {"en": "Liquids and Flow", "ru": "Жидкости и течение"},
    "card.category.assumptions_and_inference": {"en": "Assumptions and Inference", "ru": "Предположения и выводы"},
    "card.category.quality_and_priority": {"en": "Quality and Priority", "ru": "Качество и приоритет"},
    "card.category.eligibility_and_standards": {"en": "Eligibility and Standards", "ru": "Соответствие и требования"},
    "card.category.estimates_and_opinions": {"en": "Estimates and Opinions", "ru": "Оценки и мнения"},
    "card.category.references_and_directions": {"en": "References and Directions", "ru": "Ссылки и направления"},
    "card.category.support_and_dependence": {"en": "Support and Dependence", "ru": "Поддержка и зависимость"},
    "card.category.comments_and_observations": {"en": "Comments and Observations", "ru": "Замечания и наблюдения"},
    "card.category.representation_and_expression": {"en": "Representation and Expression", "ru": "Представление и выражение"},
    "card.category.retirement_and_change": {"en": "Retirement and Change", "ru": "Выход на пенсию и перемены"},
    "card.category.tearing_and_damage": {"en": "Tearing and Damage", "ru": "Разрывы и повреждения"},
    "card.category.loud_sounds": {"en": "Loud Sounds", "ru": "Громкие звуки"},
    "card.category.friction_and_rubbing": {"en": "Friction and Rubbing", "ru": "Трение и растирание"},
    "card.category.purpose_and_benefit": {"en": "Purpose and Benefit", "ru": "Цель и польза"},
    "card.category.marine_life_and_security": {"en": "Marine Life and Security", "ru": "Морская жизнь и безопасность"},
    "card.category.covers_and_layers": {"en": "Covers and Layers", "ru": "Оболочки и слои"},
    "card.category.change_and_schedules": {"en": "Change and Schedules", "ru": "Изменения и графики"},
    "card.category.coasts_and_support": {"en": "Coasts and Support", "ru": "Берега и укрепление"},
    "card.category.pushing_and_force": {"en": "Pushing and Force", "ru": "Толчки и сила"},
    "card.category.household_fixtures_and_failure": {"en": "Household Fixtures and Failure", "ru": "Предметы дома и поломки"},
    "card.category.places_and_locations": {"en": "Places and Locations", "ru": "Места и расположение"},
    "card.category.quick_sounds_and_actions": {"en": "Quick Sounds and Actions", "ru": "Резкие звуки и движения"},
    "card.category.pain_and_illness": {"en": "Pain and Illness", "ru": "Боль и недомогания"},
    "card.category.extra_and_availability": {"en": "Extra and Availability", "ru": "Запас и возможность"},
    "card.category.rigidity_and_movement": {"en": "Rigidity and Movement", "ru": "Жёсткость и движение"},
    "card.category.strips_and_removal": {"en": "Strips and Removal", "ru": "Полосы и удаление"},
    "card.category.strokes_and_actions": {"en": "Strokes and Actions", "ru": "Удары и движения"},
    "card.category.swinging_and_change": {"en": "Swinging and Change", "ru": "Качание и колебания"},
    "card.category.taps_and_faucets": {"en": "Taps and Faucets", "ru": "Касания и краны"},
    "card.category.desire_and_attraction": {"en": "Desire and Attraction", "ru": "Желание и соблазн"},
    "card.category.grammar_and_stress": {"en": "Grammar and Stress", "ru": "Грамматика и напряжение"},
    "card.category.camping_and_shelter": {"en": "Camping and Shelter", "ru": "Походы и укрытия"},
    "card.category.size_and_scale": {"en": "Size and Scale", "ru": "Размер и масштаб"},
    "card.category.advice_and_points": {"en": "Advice and Points", "ru": "Советы и кончики"},
    "card.category.food_and_celebrations": {"en": "Food and Celebrations", "ru": "Еда и тосты"},
    "card.category.tracking_and_evidence": {"en": "Tracking and Evidence", "ru": "Следы и доказательства"},
    "card.category.body_and_storage": {"en": "Body and Storage", "ru": "Тело и хранение"},
    "card.category.music_and_adjustment": {"en": "Music and Adjustment", "ru": "Музыка и настройка"},
    "card.category.change_and_difference": {"en": "Change and Difference", "ru": "Изменения и различия"},
    "card.category.exploration_and_roaming": {"en": "Exploration and Roaming", "ru": "Исследование и блуждание"},
    "card.category.warnings_and_safety": {"en": "Warnings and Safety", "ru": "Предупреждения и безопасность"},
    "card.category.contrast_and_comparison": {"en": "Contrast and Comparison", "ru": "Противопоставление и сравнение"},
    "card.category.cooking_and_force": {"en": "Cooking and Force", "ru": "Приготовление и сила"},
    "card.category.morality_and_intensity": {"en": "Morality and Intensity", "ru": "Нравственность и интенсивность"},
    "card.category.absence_and_presence": {"en": "Absence and Presence", "ru": "Отсутствие и присутствие"},
    "card.category.space_and_adaptation": {"en": "Space and Adaptation", "ru": "Размещение и приспособление"},
    "card.category.going_with_others": {"en": "Going with Others", "ru": "Сопровождение"},
    "card.category.success_and_completion": {"en": "Success and Completion", "ru": "Успех и завершение"},
    "card.category.responsibility_and_accountability": {"en": "Responsibility and Accountability", "ru": "Ответственность и подотчётность"},
    "card.category.pain_and_discomfort": {"en": "Pain and Discomfort", "ru": "Боль и дискомфорт"},
    "card.category.obtain_and_gain": {"en": "Obtaining and Gain", "ru": "Получение и приобретение"},
    "card.category.purchase_and_takeover": {"en": "Purchase and Takeover", "ru": "Покупка и приобретение"},
    "card.category.sufficiency_and_standards": {"en": "Sufficiency and Standards", "ru": "Достаточность и нормы"},
    "card.category.entry_and_acceptance": {"en": "Entry and Acceptance", "ru": "Вход и поступление"},
    "card.category.support_and_advocacy": {"en": "Support and Advocacy", "ru": "Поддержка и защита интересов"},
    "card.category.love_and_care": {"en": "Love and Care", "ru": "Любовь и забота"},
    "card.category.partnerships_and_unity": {"en": "Partnerships and Unity", "ru": "Партнёрство и единство"},
    "card.category.distribution_and_resources": {"en": "Distribution and Resources", "ru": "Распределение и ресурсы"},
    "card.category.position_and_cooperation": {"en": "Position and Cooperation", "ru": "Расположение и сотрудничество"},
    "card.category.revision_and_correction": {"en": "Revision and Correction", "ru": "Пересмотр и исправление"},
    "card.category.expectation_and_prediction": {"en": "Expectation and Prediction", "ru": "Ожидание и прогноз"},
    "card.category.emergence_and_events": {"en": "Emergence and Events", "ru": "Возникновение и события"},
    "card.category.attack_and_harm": {"en": "Attack and Harm", "ru": "Нападение и вред"},
    "card.category.confident_statements": {"en": "Confident Statements", "ru": "Утверждения"},
    "card.category.resources_and_property": {"en": "Resources and Property", "ru": "Ресурсы и имущество"},
    "card.category.tasks_and_designation": {"en": "Tasks and Designation", "ru": "Задачи и назначение"},
    "card.category.beliefs_and_estimates": {"en": "Beliefs and Estimates", "ru": "Предположения и оценки"},
    "card.category.features_and_causes": {"en": "Features and Causes", "ru": "Особенности и причины"},
    "card.category.inspection_and_accounts": {"en": "Inspection and Accounts", "ru": "Проверки и отчётность"},
    "card.category.deals_and_negotiation": {"en": "Deals and Negotiation", "ru": "Сделки и переговоры"},
    "card.category.fairness_and_prejudice": {"en": "Fairness and Prejudice", "ru": "Справедливость и предубеждения"},
    "card.category.responsibility_and_pressure": {"en": "Responsibility and Pressure", "ru": "Обязанности и давление"},
    "card.category.offices_and_departments": {"en": "Offices and Departments", "ru": "Офисы и ведомства"},
    "card.category.ability_and_volume": {"en": "Ability and Volume", "ru": "Вместимость и способности"},
    "card.category.farm_livestock": {"en": "Farm Livestock", "ru": "Сельскохозяйственный скот"},
    "card.category.stopping_and_ending": {"en": "Stopping and Ending", "ru": "Остановка и прекращение"},
    "card.category.leadership_and_titles": {"en": "Leadership and Titles", "ru": "Руководство и должности"},
    "card.category.rooms_and_spaces": {"en": "Rooms and Spaces", "ru": "Помещения и пространства"},
}

source_lines = [line.strip() for line in SOURCE.read_text(encoding="utf-8").splitlines() if line.strip()]
unique_source = list(dict.fromkeys(source_lines))
if len(unique_source) != len(source_lines):
    raise SystemExit("Source contains duplicate entries; update manifest and preserve first occurrence only.")

manifest = json.loads((BATCH_DIR / "manifest.json").read_text(encoding="utf-8"))
batches = sorted(BATCH_DIR.glob("batch-*.json"))
entries = []
for path in batches:
    batch = json.loads(path.read_text(encoding="utf-8"))
    for entry in batch["entries"]:
        entries.append(entry)

words_in_order = []
for entry in entries:
    source_entry = entry.get("source_entry", entry["word"])
    if source_entry not in words_in_order:
        words_in_order.append(source_entry)
if words_in_order != unique_source[:len(words_in_order)]:
    raise SystemExit("Draft entries are missing or out of source order.")
if words_in_order != unique_source:
    raise SystemExit(f"Refusing partial assembly: have {len(words_in_order)} of {len(unique_source)} unique entries.")

words = []
for card_id, entry in enumerate(entries, start=1):
    category = entry["category"]
    if category not in CATEGORY_NAMES:
        raise SystemExit(f"Missing category localization: {category}")
    examples = entry["examples"]
    if len(examples) != 10:
        raise SystemExit(f"{entry['word']}: expected 10 sentence pairs")
    card = {
        "word": entry["word"], "part_of_speech": entry["part_of_speech"],
        "level": entry["level"], "category": category, "id": card_id,
        "translations": [{"text": text, "language": "ru"} for text in entry["translations"]],
        "sentences": [
            {"id": card_id * 100 + i, "sentences": [
                {"text": pair[0], "language": "en"},
                {"text": pair[1], "language": "ru"},
            ]} for i, pair in enumerate(examples, start=1)
        ],
        "language": "en",
    }
    words.append(card)

used_categories = {word["category"] for word in words}
now = datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")
result = {
    "metadata": {
        "deck": {"id": "unsure_words", "language": "en", "names": {
            "en": "Alternative: Unsure Words", "ru": "Альтернативная: незнакомые слова"}},
        "source_files": [SOURCE.name],
        "source_counts": {SOURCE.name: len(source_lines)},
        "levels_included": sorted({word["level"] for word in words}),
        "total_words": len(words), "updated_at_utc": now, "schema_version": "2",
    },
    "categories": {key: CATEGORY_NAMES[key] for key in sorted(used_categories)},
    "words": words,
}

OUTPUT.parent.mkdir(parents=True, exist_ok=True)
OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
# Structural checks against both source and assembled file.
loaded = json.loads(OUTPUT.read_text(encoding="utf-8"))
assert set(loaded) == {"metadata", "categories", "words"}
assert [w["id"] for w in loaded["words"]] == list(range(1, len(words) + 1))
assert words_in_order == unique_source
assert set(loaded["categories"]) == {w["category"] for w in loaded["words"]}
assert all(len(w["sentences"]) == 10 for w in loaded["words"])
assert all(s["id"] == w["id"] * 100 + i for w in loaded["words"] for i, s in enumerate(w["sentences"], 1))
print(f"Wrote {OUTPUT}: {len(source_lines)} inputs, {len(words)} cards, {len(words)*10} sentence pairs, {len(used_categories)} categories")
