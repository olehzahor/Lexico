#!/usr/bin/env python3
"""Check saved unsure_words drafts before resuming or transferring them."""

from __future__ import annotations

import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[1] / "unsure-words.txt"
POSITIONS = {"n", "v", "adj", "adv", "pron", "det", "prep", "conj", "exclam"}
LEVELS = {"A1", "A2", "B1", "B2", "C1", "C2"}


def main() -> None:
    source = [line.strip() for line in SOURCE.read_text(encoding="utf-8").splitlines() if line.strip()]
    manifest = json.loads((HERE / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["source_nonempty_lines"] == len(source)
    assert manifest["unique_entries"] == len(set(source))

    completed = 0
    cards = 0
    seen_files = set()
    for batch in manifest["batches"]:
        assert batch["status"] == "complete", batch
        first, last = map(int, batch["lines"].split("-"))
        assert first == completed + 1 and last >= first, batch
        expected = source[first - 1 : last]
        assert batch["entries"] == expected, batch
        filename = batch["draft"]
        assert filename not in seen_files
        seen_files.add(filename)
        draft = json.loads((HERE / filename).read_text(encoding="utf-8"))
        assert draft["source_lines"] == [first, last], filename
        entries = draft["entries"]
        actual_sources = []
        for card in entries:
            word = card.get("source_entry", card["word"])
            if not actual_sources or word != actual_sources[-1]:
                actual_sources.append(word)
            assert card["part_of_speech"] in POSITIONS, (filename, word)
            assert card["level"] in LEVELS, (filename, word)
            assert card["category"].startswith("card.category."), (filename, word)
            assert card["translations"] and all(isinstance(x, str) and x.strip() for x in card["translations"])
            examples = card["examples"]
            assert len(examples) == 10, (filename, word)
            assert len({pair[0] for pair in examples}) == 10, (filename, word)
            assert all(len(pair) == 2 and all(isinstance(s, str) and s.strip() for s in pair) for pair in examples)
        assert actual_sources == expected, filename
        cards += len(entries)
        completed = last

    actual_files = {path.name for path in HERE.glob("batch-*.json")}
    assert actual_files == seen_files, (actual_files - seen_files, seen_files - actual_files)
    assert manifest["completed_source_lines"] == completed
    assert completed < len(source) or manifest["status"] == "complete"
    next_entry = source[completed] if completed < len(source) else "none"
    print(f"OK: {completed}/{len(source)} source lines; {cards} cards; {cards * 10} sentence pairs")
    print(f"Next source line: {completed + 1}; word: {next_entry}")


if __name__ == "__main__":
    main()
